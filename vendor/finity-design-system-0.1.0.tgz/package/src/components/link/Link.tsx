import { type AnchorHTMLAttributes, type ReactNode } from 'react';
import { ArrowRight } from '../icons/arrows';

export type LinkVariant = 'default' | 'cta' | 'subtle';
export type LinkBackground = 'light' | 'dark';

export interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: LinkVariant;
  background?: LinkBackground;
  iconAfter?: boolean;
  children: ReactNode;
}

export function Link({
  variant = 'default',
  background = 'light',
  iconAfter = false,
  children,
  className = '',
  ...props
}: LinkProps) {
  const base = `
    inline-flex items-center gap-[var(--spacing-4)]
    text-[16px] leading-[22px] tracking-[0.35px]
    underline decoration-solid [text-decoration-skip-ink:none]
    transition-colors duration-150
    rounded-[4px]
    outline outline-[3px] outline-transparent outline-offset-[2px]
  `;

  const weight = variant === 'cta' ? 'font-semibold' : 'font-medium';

  const color =
    variant === 'subtle'
      ? background === 'light'
        ? 'text-[var(--color-base-black)] hover:text-[#737373] hover:font-medium active:text-[var(--color-base-black)] visited:!text-[var(--color-grey-600)]'
        : 'text-[var(--color-base-white)] hover:text-[#A3A3A3] hover:font-medium active:text-[var(--color-base-white)] visited:!text-[var(--color-grey-400)]'
      : 'text-[var(--color-coral-400)] hover:text-[var(--color-coral-300)] active:text-[var(--color-coral-500)] visited:!text-[#F44C1B]';

  const focus =
    background === 'light'
      ? 'focus-visible:outline-[var(--color-grey-900)]'
      : 'focus-visible:outline-[var(--color-coral-400)]';

  return (
    <a
      className={`${base} ${weight} ${color} ${focus} ${className}`.replace(/\s+/g, ' ').trim()}
      {...props}
    >
      {children}
      {iconAfter && <ArrowRight size={16} />}
    </a>
  );
}
