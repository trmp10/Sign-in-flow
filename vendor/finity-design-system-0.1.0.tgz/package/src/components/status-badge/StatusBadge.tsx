import React from 'react';

export type StatusBadgeType = 'Success' | 'Error' | 'Warning' | 'Pending' | 'Inactive' | 'Information';
export type StatusBadgeSize = 'medium' | 'small';

export type StatusBadgeProps = {
  type: StatusBadgeType;
  size?: StatusBadgeSize;
  label?: string;
  className?: string;
};

const TYPE_COLORS: Record<StatusBadgeType, { bg: string; accent: string }> = {
  Success:     { bg: 'var(--color-green-100)',  accent: 'var(--color-green-800)'  },
  Error:       { bg: 'var(--color-red-100)',    accent: 'var(--color-red-800)'    },
  Warning:     { bg: 'var(--color-coral-100)',  accent: 'var(--color-coral-800)'  },
  Pending:     { bg: 'var(--color-yellow-100)', accent: 'var(--color-yellow-800)' },
  Inactive:    { bg: 'var(--color-grey-100)',   accent: 'var(--color-grey-800)'   },
  Information: { bg: 'var(--color-teal-100)',   accent: 'var(--color-teal-800)'   },
};

export function StatusBadge({ type, size = 'medium', label, className }: StatusBadgeProps) {
  const { bg, accent } = TYPE_COLORS[type];
  const text = label ?? type;

  const isMedium = size === 'medium';

  return (
    <div
      className={`inline-flex items-center justify-center border rounded-[4px] ${
        isMedium
          ? 'h-[32px] px-[var(--spacing-12)] text-[16px] leading-[22px] tracking-[0.35px]'
          : 'h-[24px] px-[var(--spacing-8)] text-[14px] leading-[20px] tracking-[0.3px]'
      } ${className ?? ''}`}
      style={{ backgroundColor: bg, borderColor: accent, color: accent }}
    >
      <span className="font-medium whitespace-nowrap">{text}</span>
    </div>
  );
}
