'use client';

import { type ReactNode, useState } from 'react';
import { RadioButton } from './RadioButton';

export interface RadioGroupItem {
  value: string;
  label?: ReactNode;
  description?: ReactNode;
  disabled?: boolean;
}

export interface RadioGroupProps {
  label?: string;
  name: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  orientation?: 'vertical' | 'horizontal';
  items: RadioGroupItem[];
  error?: boolean;
  className?: string;
}

export function RadioGroup({
  label,
  name,
  value,
  defaultValue,
  onChange,
  orientation = 'vertical',
  items,
  error = false,
  className = '',
}: RadioGroupProps) {
  const isControlled = value !== undefined;
  const [localValue, setLocalValue] = useState(defaultValue ?? '');
  const currentValue = isControlled ? value : localValue;

  const handleChange = (itemValue: string) => {
    if (!isControlled) setLocalValue(itemValue);
    onChange?.(itemValue);
  };

  return (
    <div className={`flex flex-col gap-[var(--spacing-8)] ${className}`} role="radiogroup">
      {label && (
        <span className="text-[14px] font-medium text-[var(--color-text-secondary)]">
          {label}
        </span>
      )}
      <div
        className={
          orientation === 'horizontal'
            ? 'flex flex-row flex-wrap gap-[var(--spacing-24)]'
            : 'flex flex-col gap-[var(--spacing-8)]'
        }
      >
        {items.map((item) => (
          <RadioButton
            key={item.value}
            name={name}
            value={item.value}
            label={item.label}
            description={item.description}
            disabled={item.disabled}
            error={error}
            checked={currentValue === item.value}
            onChange={() => handleChange(item.value)}
            tabIndex={0}
          />
        ))}
      </div>
    </div>
  );
}
