'use client';

import { type InputHTMLAttributes, type ReactNode, forwardRef, useState } from 'react';

export interface RadioButtonProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: ReactNode;
  description?: ReactNode;
  error?: boolean;
}

export const RadioButton = forwardRef<HTMLInputElement, RadioButtonProps>(
  function RadioButton(
    {
      label,
      description,
      error = false,
      disabled = false,
      checked,
      defaultChecked,
      onChange,
      className = '',
      ...props
    },
    ref
  ) {
    const isControlled = checked !== undefined;
    const [localChecked, setLocalChecked] = useState(defaultChecked ?? false);
    const isChecked = isControlled ? !!checked : localChecked;
    const [showFocusRing, setShowFocusRing] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!isControlled) setLocalChecked(e.target.checked);
      onChange?.(e);
    };

    const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
      if (e.currentTarget.matches(':focus-visible')) setShowFocusRing(true);
    };

    const handleBlur = () => setShowFocusRing(false);

    const circleClass = [
      'relative shrink-0 size-[20px] rounded-full border border-solid',
      'flex items-center justify-center',
      'transition-colors duration-100',
      showFocusRing ? 'outline outline-[3px] outline-offset-[2px] outline-[var(--color-text-default)]' : '',
      disabled
        ? 'bg-[var(--color-grey-400)] border-[var(--color-grey-400)]'
        : isChecked
        ? 'bg-[var(--color-coral-400)] border-[var(--color-coral-400)]'
        : error
        ? 'bg-[var(--color-base-white)] border-2 border-[var(--color-red-600)]'
        : 'bg-[var(--color-base-white)] border-[var(--color-border-default)] group-hover:border-2 group-hover:border-[var(--color-text-default)]',
    ].filter(Boolean).join(' ');

    return (
      <label
        className={`group inline-flex gap-[var(--spacing-8)] items-start ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'} ${className}`}
      >
        <input
          ref={ref}
          type="radio"
          checked={isControlled ? checked : undefined}
          defaultChecked={!isControlled ? defaultChecked : undefined}
          disabled={disabled}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          className="sr-only"
          {...props}
        />

        {/* Custom visual circle */}
        <div className={circleClass}>
          {(isChecked || disabled) && (
            <div className="size-[8px] rounded-full bg-[var(--color-base-white)]" aria-hidden="true" />
          )}
        </div>

        {(label || description) && (
          <span className="flex flex-col gap-[2px]">
            {label && (
              <span className="text-compact-medium text-[var(--color-grey-900)]">
                {label}
              </span>
            )}
            {description && (
              <span className={`text-compact-medium ${disabled ? 'text-[var(--color-grey-400)]' : 'text-[var(--color-text-tertiary)]'}`}>
                {description}
              </span>
            )}
          </span>
        )}
      </label>
    );
  }
);
