import { type LabelHTMLAttributes } from 'react';

export interface FieldLabelProps extends LabelHTMLAttributes<HTMLLabelElement> {}

export function FieldLabel({ children, className = '', ...props }: FieldLabelProps) {
  return (
    <label
      className={`text-body-medium text-[var(--color-text-secondary)] ${className}`.trim()}
      {...props}
    >
      {children}
    </label>
  );
}
